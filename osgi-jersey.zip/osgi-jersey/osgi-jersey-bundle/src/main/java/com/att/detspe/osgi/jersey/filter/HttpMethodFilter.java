package com.att.detspe.osgi.jersey.filter;

import java.io.IOException;
import java.util.logging.Logger;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ResourceInfo;
import javax.ws.rs.core.Context;

/** 
 * <p>Title: HttpMethodFilter.java</p> 
 * <p>Description: Description of the HttpMethodFilter.java</p>
 * <p>Copyright: Copyright (c) 2017</p>
 * <p>Company: AT&T Inc</p>
 * @author jr7365
 * @version 1.0
 * Created on Feb 1, 2017
 */
public class HttpMethodFilter implements ContainerRequestFilter {
    
    private static final Logger logger = Logger.getLogger(HttpMethodFilter.class.getName());
    
    @Context
    private ResourceInfo resourceInfo;

    /* (non-Javadoc)
     * @see javax.ws.rs.container.ContainerRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)
     */
    @Override
    public void filter(ContainerRequestContext containerRequestContext) throws IOException {
	if (!(resourceInfo.getResourceMethod().isAnnotationPresent(GET.class) ||
	      resourceInfo.getResourceMethod().isAnnotationPresent(POST.class))) {
	    logger.severe("Only GET and POST Methods are allowed");
	    throw new IOException("Only GET and POST Methods are allowed");
	}
    }

}

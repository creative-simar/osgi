package com.att.detspe.osgi.jersey;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.Application;

import com.att.detspe.osgi.jersey.resources.StatusResource;

/** 
 * <p>Title: JerseyApplication.java</p> 
 * <p>Description: Description of the JerseyApplication.java</p>
 * <p>Copyright: Copyright (c) 2017</p>
 * <p>Company: AT&T Inc</p>
 * @author jr7365
 * @version 1.0
 * Created on Feb 1, 2017
 */
public class JerseyApplication extends Application {
    
    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> result = new HashSet<Class<?>>();
        result.add(StatusResource.class);
        return result;
    }

}

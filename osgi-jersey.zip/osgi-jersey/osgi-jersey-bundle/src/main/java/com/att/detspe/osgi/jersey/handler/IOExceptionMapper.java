package com.att.detspe.osgi.jersey.handler;

import java.io.IOException;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

/** 
 * <p>Title: IOExceptionMapper.java</p> 
 * <p>Description: Description of the IOExceptionMapper.java</p>
 * <p>Copyright: Copyright (c) 2017</p>
 * <p>Company: AT&T Inc</p>
 * @author jr7365
 * @version 1.0
 * Created on Feb 1, 2017
 */
@Provider
public class IOExceptionMapper implements ExceptionMapper<IOException> {

    @Override
    public Response toResponse(IOException ioEx) {
	String response = ioEx.getMessage();
	return Response.status(200).entity(response).type(MediaType.TEXT_HTML_TYPE).build();
    }

}

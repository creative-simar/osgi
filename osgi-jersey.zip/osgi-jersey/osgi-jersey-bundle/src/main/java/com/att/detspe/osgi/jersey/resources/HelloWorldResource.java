package com.att.detspe.osgi.jersey.resources;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** 
 * <p>Title: HelloWorldResource.java</p> 
 * <p>Description: Description of the HelloWorldResource.java</p>
 * <p>Copyright: Copyright (c) 2017</p>
 * <p>Company: AT&T Inc</p>
 * @author jr7365
 * @version 1.0
 * Created on Feb 1, 2017
 */
@Path("helloworld")
public class HelloWorldResource {
    
    private static final Logger logger = LoggerFactory.getLogger(HelloWorldResource.class);

    @GET
    @Produces("text/plain")
    @Path("get")
    public String getStatus() {
	logger.info("Returning Hello World Response");
        return "Hello World !!";
    }
    
}


package com.att.detspe.osgi.jersey;

import java.util.logging.Logger;

import org.glassfish.jersey.server.ResourceConfig;

/** 
 * <p>Title: JerseyApplicationResourceConfig.java</p> 
 * <p>Description: Description of the JerseyApplicationResourceConfig.java</p>
 * <p>Copyright: Copyright (c) 2017</p>
 * <p>Company: AT&T Inc</p>
 * @author jr7365
 * @version 1.0
 * Created on Feb 1, 2017
 */
public class JerseyApplicationResourceConfig extends ResourceConfig {
    
    private static final Logger logger = Logger.getLogger(JerseyApplicationResourceConfig.class.getName());
	
    /** The Constant BASE_PACKAGE. */
    private static final String BASE_PACKAGE = "com.att.detspe.osgi";

    /**
     * Instantiates a new application resource config.
     */
    public JerseyApplicationResourceConfig() {
	// Base Bus Logic Framework Package
	logger.info("Registering Package for Scanning: [Package]: " + BASE_PACKAGE);
	packages(BASE_PACKAGE);
	logger.info("Registed the Package successfully.  [Package]: " + BASE_PACKAGE);
    }

}

package com.att.detspe.osgi.jersey.resources;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** 
 * <p>Title: StatusResource.java</p> 
 * <p>Description: Description of the StatusResource.java</p>
 * <p>Copyright: Copyright (c) 2017</p>
 * <p>Company: AT&T Inc</p>
 * @author jr7365
 * @version 1.0
 * Created on Feb 1, 2017
 */
@Path("status")
public class StatusResource {
    
    private static final Logger logger = LoggerFactory.getLogger(StatusResource.class.getName());

    @GET
    @Produces("text/plain")
    @Path("get")
    public String getStatus() {
	logger.info("Returning Status Responsee");
        return "Active";
    }
    
}

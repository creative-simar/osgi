package com.att.detspe.osgi.jersey;

import java.util.Dictionary;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.logging.Logger;

import javax.servlet.ServletException;

import org.glassfish.jersey.servlet.ServletContainer;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.service.event.Event;
import org.osgi.service.event.EventAdmin;
import org.osgi.service.http.HttpService;
import org.osgi.service.http.NamespaceException;
import org.osgi.util.tracker.ServiceTracker;

/** 
 * <p>Title: JerseyActivator.java</p> 
 * <p>Description: Description of the JerseyActivator.java</p>
 * <p>Copyright: Copyright (c) 2017</p>
 * <p>Company: AT&T Inc</p>
 * @author jr7365
 * @version 1.0
 * Created on Feb 1, 2017
 */
public class JerseyActivator implements BundleActivator {
    
    private static final Logger logger = Logger.getLogger(JerseyActivator.class.getName());
    
    private static final String CONTEXT_PATH = "/osgi-jersey";
    
    private BundleContext bundleContext;
    private ServiceTracker serviceTracker;
    private HttpService httpService;

    /* (non-Javadoc)
     * @see org.osgi.framework.BundleActivator#start(org.osgi.framework.BundleContext)
     */
    public void start(BundleContext bundleContext) throws Exception {
	logger.info("Jersey Activator - Starting");
	this.bundleContext = bundleContext;
	logger.info("Starting the HttpService Bundle");
        this.serviceTracker = new ServiceTracker(this.bundleContext, HttpService.class.getName(), null) {

            @Override
            public Object addingService(ServiceReference serviceRef) {
                httpService = (HttpService) super.addingService(serviceRef);
                registerServlets();
                return httpService;
            }

            @Override
            public void removedService(ServiceReference ref, Object service) {
                if (httpService == service) {
                    unregisterServlets();
                    httpService = null;
                }
                super.removedService(ref, service);
            }
        };

        this.serviceTracker.open();
        logger.info("Jersey Activator - Started");
    }

    /* (non-Javadoc)
     * @see org.osgi.framework.BundleActivator#stop(org.osgi.framework.BundleContext)
     */
    public void stop(BundleContext context) throws Exception {
	this.serviceTracker.close();
    }
    
    private void registerServlets() {
        try {
            rawRegisterServlets();
        } catch (InterruptedException | NamespaceException | ServletException ie) {
            throw new RuntimeException(ie);
        }
    }

    private void rawRegisterServlets() throws ServletException, NamespaceException, InterruptedException {
        logger.info("Jersey Bundle: Registering Servlets to Http Service = " + httpService.toString());

        //TODO - Temporary workaround
        // This is a workaround related to issue JERSEY-2093; grizzly (1.9.5) needs to have the correct context classloader set
        ClassLoader myClassLoader = getClass().getClassLoader();
        ClassLoader originalContextClassLoader = Thread.currentThread().getContextClassLoader();
        try {
            Thread.currentThread().setContextClassLoader(myClassLoader);
            httpService.registerServlet(CONTEXT_PATH, new ServletContainer(), getJerseyServletParams(), null);
        } finally {
            Thread.currentThread().setContextClassLoader(originalContextClassLoader);
        }
        // END of workaround - after grizzly updated to the recent version, only the inner call from try block will remain:
        // httpService.registerServlet("/jersey-http-service", new ServletContainer(), getJerseyServletParams(), null);

        sendAdminEvent();
        logger.info("Jersey Bundle: Servlets Registered Successfully");
    }

    private void sendAdminEvent() {
        ServiceReference eaRef = bundleContext.getServiceReference(EventAdmin.class.getName());
        if (eaRef != null) {
            EventAdmin ea = (EventAdmin) bundleContext.getService(eaRef);
            ea.sendEvent(new Event("jersey/test/DEPLOYED", new HashMap<String, String>() {
                private static final long serialVersionUID = 1L;
		{
                    put("context-path", "/");
                }
            }));
            logger.info("Event sent successfully");
            bundleContext.ungetService(eaRef);
        }
    }

    private void unregisterServlets() {
        if (this.httpService != null) {
            logger.info("Jersey Bundle: Unregistering Servlets");
            httpService.unregister(CONTEXT_PATH);
            logger.info("Jersey Bundle: Servlets Unregistered");
        }
    }

    private Dictionary<String, String> getJerseyServletParams() {
	Dictionary<String, String> jerseyServletParams = new Hashtable<>();
        jerseyServletParams.put("javax.ws.rs.Application", JerseyApplicationResourceConfig.class.getName());
        logger.info("Jersey Servlet Params: " + jerseyServletParams);
        return jerseyServletParams;
    }

}
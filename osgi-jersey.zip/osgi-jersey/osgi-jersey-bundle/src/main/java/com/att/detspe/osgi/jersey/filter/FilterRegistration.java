package com.att.detspe.osgi.jersey.filter;

import java.util.logging.Logger;

import javax.ws.rs.container.DynamicFeature;
import javax.ws.rs.container.ResourceInfo;
import javax.ws.rs.core.FeatureContext;
import javax.ws.rs.ext.Provider;

/** 
 * <p>Title: FilterRegistration.java</p> 
 * <p>Description: Description of the FilterRegistration.java</p>
 * <p>Copyright: Copyright (c) 2017</p>
 * <p>Company: AT&T Inc</p>
 * @author jr7365
 * @version 1.0
 * Created on Feb 1, 2017
 */
@Provider
public class FilterRegistration implements DynamicFeature {
    
    private static final Logger logger = Logger.getLogger(DynamicFeature.class.getName());    

    /* (non-Javadoc)
     * @see javax.ws.rs.container.DynamicFeature#configure(javax.ws.rs.container.ResourceInfo, javax.ws.rs.core.FeatureContext)
     */
    @Override
    public void configure(ResourceInfo resourceInfo, FeatureContext featureContext) {
	featureContext.register(HttpMethodFilter.class, 100);
	logger.info("Registered the HttpMethodFilter successfully. [FeatureContext]: " + resourceInfo.getResourceClass() + "." + resourceInfo.getResourceMethod());
    }

}
